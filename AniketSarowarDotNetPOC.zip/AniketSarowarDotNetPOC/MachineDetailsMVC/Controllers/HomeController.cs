﻿using MachineDetailsMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class HomeController : Controller
{
    private readonly HttpClient _httpClient;

    public HomeController(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient();
        _httpClient.BaseAddress = new Uri("https://localhost:7098/");
    }

    public async Task<IActionResult> Index()
    {

        string response = await _httpClient.GetStringAsync("machine");
        if (response != null)
        {
            var machineDetails = JsonConvert.DeserializeObject<dynamic>(response); ;

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            ViewBag.MachineName = machineDetails.machineName;
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            ViewBag.MachineIP = machineDetails.machineIP;
            ViewBag.MachineOS = machineDetails.machineOS;
            ViewBag.Timestamp = machineDetails.timestamp;
        }

        return View();
    }
}